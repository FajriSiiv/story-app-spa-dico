export function generateSaveStoryButtonTemplate() {
  return `<button id="story-detail-save">Simpan Story</button>`;
}

export function generateRemoveStoryButtonTemplate() {
  return `<button id="story-detail-remove">Hapus Story</button>`;
}
